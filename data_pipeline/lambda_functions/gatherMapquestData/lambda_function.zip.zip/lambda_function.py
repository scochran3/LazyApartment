# Lambda function that takes raw craigslist data
# and adds Mapquest data based on the lat/lon
import json
import requests
import boto3

def lambda_handler(event, context):
	# Read in data
	with open('data.json', 'r') as data_file:
		data = data_file.read()
		data = json.loads(data)

	# Enrich with Mapquest Data
	enhancedData = []
	for row in data:
		endpoint = """http://www.mapquestapi.com/geocoding/v1/reverse?key=iw6qVAKiRuuwCdWABAoG5A7isfLhbGRZ&location={},{}&includeRoadMetadata=true&includeNearestIntersection=true&outFormat=json""".format(row['geotag'][0], row['geotag'][1])
		r = requests.get(endpoint)
		mapquestData = json.loads(r.content)
		row['postalCode'] = mapquestData['results'][0]['locations'][0]['postalCode']
		row['sideOfStreet'] = mapquestData['results'][0]['locations'][0]['sideOfStreet']
		row['distanceToNearestIntersection'] = mapquestData['results'][0]['locations'][0]['nearestIntersection']['distanceMeters']
		row['address'] = mapquestData['results'][0]['locations'][0]['street']
		enhancedData.append(row)

	# Convert to JSON
	data = json.dumps(enhancedData)

	# Upload enriched data to S3
	client = boto3.client('s3')
	response = client.put_object(Bucket='lazyapartment', 
					Body=data, 
					Key='mapquestEnhancedData/test.json')